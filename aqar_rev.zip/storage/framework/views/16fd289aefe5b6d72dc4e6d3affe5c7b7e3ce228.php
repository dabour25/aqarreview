<?php $__env->startSection('content'); ?>
    <style>
        .form-control {
            width: 100%;
            min-width: 100px;
        }

        @media (max-width: 786px) {
            .card-body {
                padding: 10px 0;
            }
        }
    </style>
    <div id="content-wrapper">

        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="/admindb">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Control Users</li>
            </ol>

            <!-- Page Content -->
            <?php if(count($errors)>0): ?>
                <br>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(Session::has('m')): ?>
                <?php $a = []; $a = session()->pull('m'); ?>
                <div class="alert alert-<?php echo e($a[0]); ?>" style="width: 40%">
                    <?php echo e($a[1]); ?>

                </div>
            <?php endif; ?>
        <!-- Page Content -->
            <form action="/admindb/users/1" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field("PUT")); ?>

                <button type="submit" class="btn btn-primary">Save Changes</button>
                <select class="form-control"
                        style="width: 150px;display: inline;position: relative; top: 2px;left:20px;" id="filter">
                    <option value="">Select Filter</option>
                    <option value="admin" <?php echo e(isset($filter)&&$filter=='admin'?'selected':''); ?>>Admin</option>
                    <option value="user" <?php echo e(isset($filter)&&$filter=='user'?'selected':''); ?>>User</option>
                    <option value="developer" <?php echo e(isset($filter)&&$filter=='developer'?'selected':''); ?>>Developer</option>
                    <option value="broker" <?php echo e(isset($filter)&&$filter=='broker'?'selected':''); ?>>Broker</option>
                    <option value="owner" <?php echo e(isset($filter)&&$filter=='owner'?'selected':''); ?>>Owner</option>
                    <option value="renter" <?php echo e(isset($filter)&&$filter=='renter'?'selected':''); ?>>Renter</option>
                    <option value="engineer" <?php echo e(isset($filter)&&$filter=='engineer'?'selected':''); ?>>Engineer</option>
                    <option value="contractor" <?php echo e(isset($filter)&&$filter=='contractor'?'selected':''); ?>>Contractor</option>
                    <option value="corporate" <?php echo e(isset($filter)&&$filter=='corporate'?'selected':''); ?>>Corporate</option>
                    <option value="blocked" <?php echo e(isset($filter)&&$filter=='blocked'?'selected':''); ?>>Blocked</option>
                    <option value="removed" <?php echo e(isset($filter)&&$filter=='removed'?'selected':''); ?>>Removed</option>
                </select>
                <script type="text/javascript">
                    $('#filter').change(function () {
                        if ($('#filter').val() == "") {
                            location.href = '/admindb/users';
                        } else {
                            location.href = '/admindb/users?filter=' + $('#filter').val();
                        }
                    });
                </script>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-dark">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Password</th>
                                <th scope="col">Role</th>
                                <th scope="col"><?php echo e(isset($filter)&&$filter=='removed'?'Restore':'Remove'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th scope="row"><?php echo e($k+1); ?></th>
                                <td><input type="text" class="form-control" name="name[<?php echo e($a->id); ?>]"
                                           value="<?php echo e($a->name); ?>"></td>
                                <td><input type="text" class="form-control" name="email[<?php echo e($a->id); ?>]"
                                           value="<?php echo e($a->email); ?>"></td>
                                <td><input type="text" class="form-control" name="phone[<?php echo e($a->id); ?>]"
                                           value="<?php echo e($a->phone); ?>"></td>
                                <td><input type="text" class="form-control" name="password[<?php echo e($a->id); ?>]"></td>
                                <?php if(isset($a->role)||$a->id!=1): ?>
                                    <td>
                                        <select name="role[<?php echo e($a->id); ?>]" class="form-control">
                                            <option value="user" <?php echo e($a->role=='user'?'selected':''); ?>>User</option>
                                            <option value="developer" <?php echo e($a->role=='developer'?'selected':''); ?>>
                                                Developer
                                            </option>
                                            <option value="broker" <?php echo e($a->role=='broker'?'selected':''); ?>>Broker</option>
                                            <option value="owner" <?php echo e($a->role=='owner'?'selected':''); ?>>Owner</option>
                                            <option value="renter" <?php echo e($a->role=='renter'?'selected':''); ?>>Renter</option>
                                            <option value="engineer" <?php echo e($a->role=='engineer'?'selected':''); ?>>Engineer</option>
                                            <option value="contractor" <?php echo e($a->role=='contractor'?'selected':''); ?>>Contractor</option>
                                            <option value="corporation" <?php echo e($a->role=='corporation'?'selected':''); ?>>Corporation</option>
                                            <option value="blocked" <?php echo e($a->role=='blocked'?'selected':''); ?>>Blocked</option>
                                        </select>
                                    </td>
                                    <?php if(isset($filter)&&$filter=='removed'): ?>
                                        <td><a id="remove<?php echo e($a->slug); ?>" class="btn btn-info">R</a></td>
                                    <?php else: ?>
                                        <td><a id="remove<?php echo e($a->slug); ?>" class="btn btn-danger">X</a></td>
                                    <?php endif; ?>
                                    <script>
                                        $('#remove<?php echo e($a->slug); ?>').click(function () {
                                            $("#remove-form<?php echo e($a->slug); ?>").submit();
                                        });
                                    </script>
                                <?php else: ?>
                                    <td>Admin</td>
                                    <td></td>
                                    <?php endif; ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php echo e($users->links()); ?>

            </form>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form action="/admindb/users/<?php echo e($a->slug); ?>" method="POST" id="remove-form<?php echo e($a->slug); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field("DELETE")); ?>

                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
    <!-- /.content-wrapper -->

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/admin/users.blade.php ENDPATH**/ ?>