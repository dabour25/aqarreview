<?php $__env->startSection('content'); ?>

<?php if(count($errors)>0): ?>
<div class="alert alert-danger <?php echo e(!session()->has('lang')?'ar':''); ?>">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(Session::has('m')): ?>
  <?php $a=[]; $a=session()->pull('m'); ?>
  <div class="alert alert-<?php echo e($a[0]); ?> <?php echo e(!session()->has('lang')?'ar':''); ?>">
    <?php echo e($a[1]); ?>

  </div>
<?php endif; ?>
<!-- Page Content-->
<section>
	<div class="row" style="width: 45%;margin: auto;">
		<div class="col-md-5 card my-card card-selected">
			<?php echo app('translator')->getFromJson('strings.posts'); ?>
		</div>
		<div class="col-md-5 card my-card">
			<a href="/blogs" style="all: unset;"><?php echo app('translator')->getFromJson('strings.blogs'); ?></a>
		</div>
	</div>
</section>
<hr>
<section class="<?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
	<?php if(auth()->user()): ?>
		<div class="card post p-1">
			<form action="/posts" method="POST" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<textarea class="form-control" name="post"
						  placeholder="<?php echo app('translator')->getFromJson('strings.type_post'); ?>"></textarea>
				<br>
				<input type="file" name="images[]" class="custom-file-input" multiple
					   accept="image/gif, image/jpeg, image/png" id="post-img">
				<br><br>
				<button type="submit"
						class="btn follow-btn btn-sm"><?php echo app('translator')->getFromJson('strings.send'); ?></button>
				<div id="images">

				</div>
			</form>
		</div>
	<?php endif; ?>
	<div class="main-title" style="margin-bottom: 10px;margin-top: 20px;">
		<h4><?php echo app('translator')->getFromJson('strings.new_posts'); ?></h4>
	</div>
	<!--Post-->
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card post">
				<div class="row">
					<img src="<?php echo e(asset('img/profiles').'/'.($post->users->images?($post->users->images[0]->url??'default.png'):'default.png')); ?>" class="post-img">
					<span class="post-name"><?php echo e($post->users->name); ?><p class="post-name-tiny">(<?php echo e($post->created_at); ?>) <span class="post-follow">Follow</span></p></span>
				</div>
				<hr>
				<p class="post-body"><?php echo e($post->content); ?></p>
				<hr>
				<div class="row">
					<?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4">
							<img src="<?php echo e(asset('img/posts').'/'.$image->url); ?>" width="100%" height="200px" style="padding: 10px;">
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<hr>
				<div class="row" style="width:80%;margin: auto;">
					<?php $isliked=$isdislike=false;$likescount=$dislikescount=0 ?>

					<?php $__currentLoopData = $post->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(auth()->user()): ?>
							<?php if($like->user_id==auth()->user()->id&&$like->type==1): ?>
								<?php $isliked=true; ?>
								<?php break; ?>;
							<?php elseif($like->user_id==auth()->user()->id&&$like->type==0): ?>
								<?php $isdislike=true; ?>
								<?php break; ?>;
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<a class="col-sm-3" href="/like-post/<?php echo e($post->slug); ?>"><i class="fa fa-thumbs<?php echo e($isliked?'':'-o'); ?>-up"></i> <?php echo app('translator')->getFromJson('strings.like'); ?> (<?php echo e($likes[$post->id]); ?>)</a>
					<a class="col-sm-3" href="/dislike-post/<?php echo e($post->slug); ?>"><i class="fa fa-thumbs<?php echo e($isdislike?'':'-o'); ?>-down"></i> <?php echo app('translator')->getFromJson('strings.dislike'); ?> (<?php echo e($dislikes[$post->id]); ?>)</a>
					<div class="col-sm-6" style="cursor: pointer" id="comment_btn<?php echo e($post->slug); ?>"><i class="fa fa-comment"></i> <?php echo app('translator')->getFromJson('strings.comment'); ?>(<?php echo e(count($post->comments)); ?>)</div>
					<br><br>
					<div class="col-sm-12" id="comment_tab<?php echo e($post->slug); ?>" style="display: none;">
						<?php if(auth()->user()): ?>
							<form action="/posts/comment/<?php echo e($post->slug); ?>" method="post">
								<?php echo csrf_field(); ?>
								<input type="text" name="comment" class="form-control">
								<button class="btn btn-primary" style="margin: 5px 0;" type="submit"><?php echo app('translator')->getFromJson('strings.comment'); ?></button>
							</form>
						<?php endif; ?>
						<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $isliked=$isdislike=false; ?>
							<?php $__currentLoopData = $comment->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if(auth()->user()): ?>
									<?php if($like->user_id==auth()->user()->id&&$like->type==1): ?>
										<?php $isliked=true; ?>
										<?php break; ?>;
									<?php elseif($like->user_id==auth()->user()->id&&$like->type==0): ?>
										<?php $isdislike=true; ?>
										<?php break; ?>;
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<div class="row">
								<div class="col-sm-12">
									<img src="<?php echo e(asset('img/profiles').'/'.($comment->user->images?($comment->user->images[0]->url??'default.png'):'default.png')); ?>" class="comment-img">
									<span class="comment-name"><?php echo e($comment->user->name); ?>

							<p> <?php echo e($comment->comment); ?></p>
						</span>
								</div>
								<div class="col-sm-12 mx-1">
									<div class="row">
										<a class="col-sm-3" href="/like-comment/<?php echo e($comment->id); ?>"><i class="fa fa-thumbs<?php echo e($isliked?'':'-o'); ?>-up"></i> <?php echo app('translator')->getFromJson('strings.like'); ?> (<?php echo e($commentlikes[$post->id][$comment->id]); ?>)</a>
										<a class="col-sm-3" href="/dislike-comment/<?php echo e($comment->id); ?>"><i class="fa fa-thumbs<?php echo e($isdislike?'':'-o'); ?>-down"></i> <?php echo app('translator')->getFromJson('strings.dislike'); ?> (<?php echo e($commentdislikes[$post->id][$comment->id]); ?>)</a>
										<div class="col-sm-6" style="cursor: pointer" id="reply_btn<?php echo e($comment->id); ?>"><i class="fa fa-comment"></i> <?php echo app('translator')->getFromJson('strings.reply'); ?>(<?php echo e(count($comment->replies)); ?>)</div>
										<div class="col-sm-12" id="reply_tab<?php echo e($comment->id); ?>" style="display: none;">
											<?php if(auth()->user()): ?>
												<form action="/comments/reply/<?php echo e($comment->id); ?>" method="post">
													<?php echo csrf_field(); ?>
													<input type="text" name="reply" class="form-control">
													<button class="btn btn-primary" style="margin: 5px 0;" type="submit"><?php echo app('translator')->getFromJson('strings.reply'); ?></button>
												</form>
											<?php endif; ?>
											<?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php $isliked=$isdislike=false; ?>
												<?php $__currentLoopData = $reply->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if(auth()->user()): ?>
														<?php if($like->user_id==auth()->user()->id&&$like->type==1): ?>
															<?php $isliked=true; ?>
															<?php break; ?>;
														<?php elseif($like->user_id==auth()->user()->id&&$like->type==0): ?>
															<?php $isdislike=true; ?>
															<?php break; ?>;
														<?php endif; ?>
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<div class="row">
													<div class="col-sm-12">
														<img src="<?php echo e(asset('img/profiles').'/'.($reply->user->images?($reply->user->images[0]->url??'default.png'):'default.png')); ?>" class="comment-img">
														<span class="comment-name"><?php echo e($reply->user->name); ?>

												<p> <?php echo e($reply->reply); ?></p>
											</span>
													</div>
													<div class="col-sm-8 mx-1">
														<div class="row">
															<a class="col-sm-6" href="/like-reply/<?php echo e($reply->id); ?>"><i class="fa fa-thumbs<?php echo e($isliked?'':'-o'); ?>-up"></i> <?php echo app('translator')->getFromJson('strings.like'); ?> (<?php echo e($replieslikes[$post->id][$comment->id][$reply->id]); ?>)</a>
															<a class="col-sm-6" href="/dislike-reply/<?php echo e($reply->id); ?>"><i class="fa fa-thumbs<?php echo e($isdislike?'':'-o'); ?>-down"></i> <?php echo app('translator')->getFromJson('strings.dislike'); ?> (<?php echo e($repliesdislikes[$post->id][$comment->id][$reply->id]); ?>)</a>
														</div>
													</div>
													<hr>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>
								<hr>
							</div>
							<script>
								$('#reply_btn<?php echo e($comment->id); ?>').click(function () {
									$('#reply_tab<?php echo e($comment->id); ?>').toggle();
								});
							</script>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<br>
			<script>
				$('#comment_btn<?php echo e($post->slug); ?>').click(function () {
					$('#comment_tab<?php echo e($post->slug); ?>').toggle();
				});
			</script>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
		
	
</section>
<!-- // End Page Content -->
	<script>
		function readURL(input) {
			$('#images').html('');
			var files = event.target.files; //FileList object
			for (var i = 0; i < files.length; i++) {
				var file = files[i];
				//Only pics
				if (!file.type.match('image')) continue;

				var picReader = new FileReader();
				picReader.addEventListener("load", function (event) {
					var picFile = event.target;
					$('#images').append('<img src="'+picFile.result+'" class="showimg">');
				});
				//Read the image
				picReader.readAsDataURL(file);
			}
		}
		$("#post-img").change(function(){
			readURL(this);
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/posts.blade.php ENDPATH**/ ?>