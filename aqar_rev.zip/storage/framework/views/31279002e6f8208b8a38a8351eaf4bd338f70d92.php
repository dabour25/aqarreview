<?php $__env->startSection('content'); ?>
<?php if(count($errors)>0): ?>
<div class="alert alert-danger <?php echo e(!session()->has('lang')?'ar':''); ?>">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(Session::has('m')): ?>
  <?php $a=[]; $a=session()->pull('m'); ?>
  <div class="alert alert-<?php echo e($a[0]); ?> <?php echo e(!session()->has('lang')?'ar':''); ?>" style="width: 40%">
    <?php echo e($a[1]); ?>

  </div>
<?php endif; ?>
<!-- Page Content-->
<h3 class="title"><?php echo app('translator')->getFromJson('strings.add_advertise'); ?></h3>
<form action="/ads" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="form-group loginform">
	<div class="row <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
		<div class="col-sm-6">
			<label><?php echo app('translator')->getFromJson('strings.advertise_name'); ?></label>
			<input type="text" class="form-control <?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" value="<?php echo e(old('title')); ?>">
		</div>
		<div class="col-sm-6">
			<label><?php echo app('translator')->getFromJson('strings.price'); ?></label>
			<input type="number" class="form-control <?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.price_str'); ?>" name="price"  value="<?php echo e(old('price')); ?>">
		</div>
		<div class="col-sm-12">
			<label><?php echo app('translator')->getFromJson('strings.description'); ?></label>
			<textarea class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description"><?php echo e(old('description')); ?></textarea>
		</div>
		<div class="col-sm-6">
			<label> <?php echo app('translator')->getFromJson('strings.area'); ?>(<?php echo app('translator')->getFromJson('strings.meter_square'); ?>)</label>
			<input type="number" class="form-control <?php echo e($errors->has('size') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.area_str'); ?>" name="size" value="<?php echo e(old('size')); ?>">
		</div>
		<div class="col-sm-6">
			<label><?php echo app('translator')->getFromJson('strings.gen_type'); ?></label>
			<select class="form-control" id="general_type" name="general_type">
				<option value="sell" <?php echo e(old('general_type')=='sell'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.sell'); ?></option>
				<option value="rent" <?php echo e(old('general_type')=='rent'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.rent'); ?></option>
			</select>
		</div>
		<div class="col-sm-6">
			<label><?php echo app('translator')->getFromJson('strings.type'); ?></label>
			<select class="form-control" name="type" id="type">
				<option value="apartment" <?php echo e(old('type')=='apartment'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.apartment'); ?></option>
                <option value="villa" <?php echo e(old('type')=='villa'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.villa'); ?></option>
				<option id="land" value="land" <?php echo e(old('type')=='land'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.land'); ?></option>
				<option id="homes" value="houses" <?php echo e(old('type')=='houses'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.houses'); ?></option>
                <option value="shop" <?php echo e(old('type')=='shop'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.shop'); ?></option>
				<option value="chalet" <?php echo e(old('type')=='chalet'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.chalet'); ?></option>
			</select>
		</div>
		<script type="text/javascript">
			$('#general_type').change(function(){
				if($('#general_type').val()=='rent'){
					$('#land').hide();
					$('#homes').hide();
				}else{
					$('#land').show();
					$('#homes').show();
				}
			});
			$('#type').change(function(){
				if($('#type').val()=='land'){
					$('#floor').hide();
					$('#rooms').hide();
					$('#pathroom').hide();
					$('#kitchens').hide();
					$('#finish').hide();
					$('#furniture').hide();
					$('#parking').hide();
				}else{
					$('#floor').show();
					$('#rooms').show();
					$('#pathroom').show();
					$('#kitchens').show();
					$('#finish').show();
					$('#furniture').show();
					$('#parking').show();
				}
			});
			<?php if(old('type')=='land'): ?>
			function f(){
				$('#floor').hide();
				$('#rooms').hide();
				$('#pathroom').hide();
				$('#kitchens').hide();
				$('#finish').hide();
				$('#furniture').hide();
				$('#parking').hide();
			}
			f();
			<?php endif; ?>
		</script>
		<div class="col-sm-6" id="floor">
			<label><?php echo app('translator')->getFromJson('strings.floor'); ?></label>
			<input type="number" class="form-control <?php echo e($errors->has('floor') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.floor_str'); ?>" name="floor" value="<?php echo e(old('floor')); ?>">
		</div>
		<div class="col-sm-6" id="rooms">
			<label><?php echo app('translator')->getFromJson('strings.rooms'); ?></label>
			<input type="number" class="form-control <?php echo e($errors->has('rooms') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.rooms_str'); ?>" name="rooms" value="<?php echo e(old('rooms')); ?>">
		</div>
		<div class="col-sm-6" id="pathroom">
			<label><?php echo app('translator')->getFromJson('strings.bathrooms_count'); ?></label>
			<input type="number" class="form-control <?php echo e($errors->has('pathrooms') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.bathrooms_str'); ?>" name="pathrooms" value="<?php echo e(old('pathrooms')); ?>">
		</div>
		<div class="col-sm-6" id="kitchens">
			<label><?php echo app('translator')->getFromJson('strings.kitchens'); ?></label>
			<input type="number" class="form-control <?php echo e($errors->has('kitchens') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.kitchens_str'); ?>" name="kitchens" value="<?php echo e(old('kitchens')); ?>">
		</div>
		<div class="col-sm-6" id="finish">
			<label><?php echo app('translator')->getFromJson('strings.finishing'); ?></label>
			<select class="form-control" name="finish">
				<option value="full" <?php echo e(old('finish')==1?'selected':'full'); ?>><?php echo app('translator')->getFromJson('strings.full'); ?></option>
                <option value="not_full" <?php echo e(old('finish')==2?'selected':'not_full'); ?>><?php echo app('translator')->getFromJson('strings.not_full'); ?></option>
                <option value="red_bricks" <?php echo e(old('finish')==3?'selected':'red_bricks'); ?>><?php echo app('translator')->getFromJson('strings.red_brick'); ?></option>
			</select>
		</div>
		<div class="col-sm-6" id="furniture">
			<label><?php echo app('translator')->getFromJson('strings.furniture'); ?></label>
			<select class="form-control" name="furniture">
				<option value="yes" <?php echo e(old('furniture')=='yes'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.yes'); ?></option>
                <option value="no" <?php echo e(old('furniture')=='no'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.no'); ?></option>
			</select>
		</div>
		<div class="col-sm-6" id="parking">
			<label><?php echo app('translator')->getFromJson('strings.park'); ?></label>
			<select class="form-control" name="parking">
				<option value="yes" <?php echo e(old('parking')=='yes'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.yes'); ?></option>
                <option value="no" <?php echo e(old('parking')=='no'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.no'); ?></option>
			</select>
		</div>
		<div class="col-sm-12">
			<label style="<?php echo e($errors->has('image') ? 'color:red;' : ''); ?>"><?php echo app('translator')->getFromJson('strings.images'); ?></label>
			<br>
			<input type="file" name="images[]" class="custom-file-input" multiple accept="image/gif, image/jpeg, image/png" id="profile-img">
			<div id="images">
				
			</div>
			<script type="text/javascript">
			    function readURL(input) {
			    	$('#images').html('');
			        var files = event.target.files; //FileList object
			        for (var i = 0; i < files.length; i++) {
			            var file = files[i];
			            //Only pics
			            if (!file.type.match('image')) continue;

			            var picReader = new FileReader();
			            picReader.addEventListener("load", function (event) {
			                var picFile = event.target;
			                $('#images').append('<img src="'+picFile.result+'" class="showimg">');
			            });
			            //Read the image
			            picReader.readAsDataURL(file);
			        }
			    }
			    $("#profile-img").change(function(){
			        readURL(this);
			    });
			</script>
		</div>
		<div class="col-sm-12">
			<label><?php echo app('translator')->getFromJson('strings.address'); ?></label>
			<textarea class="form-control <?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address"><?php echo e(old('address')); ?></textarea>
		</div>
		<div class="col-sm-12" style="margin-top:20px;">
			<button type="submit" class="btn btn-white"><?php echo app('translator')->getFromJson('strings.confirm_data'); ?></button>
		</div>
	</div>
</div>
</form>
<!-- // End Page Content -->
<script type="text/javascript">
	<?php if(old('general_type')=='rent'): ?>
		$('#land').hide();
		$('#homes').hide();
	<?php endif; ?>
	<?php if(old('type')=='land'): ?>
		$('#floor').hide();
		$('#rooms').hide();
		$('#pathroom').hide();
		$('#kitchens').hide();
		$('#finish').hide();
		$('#furniture').hide();
		$('#parking').hide();
	<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/addnew.blade.php ENDPATH**/ ?>