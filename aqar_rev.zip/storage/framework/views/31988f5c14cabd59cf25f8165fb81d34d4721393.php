<?php $__env->startSection('content'); ?>

    <?php if(count($errors)>0): ?>
        <div class="alert alert-danger <?php echo e(!session()->has('lang')?'ar':''); ?>">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
        <?php $a = []; $a = session()->pull('m'); ?>
        <div class="alert alert-<?php echo e($a[0]); ?> <?php echo e(!session()->has('lang')?'ar':''); ?>">
            <?php echo e($a[1]); ?>

        </div>
    <?php endif; ?>
    <!-- Page Content-->
    <div class="col-md-12">
        <br>
        <div class="row <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
            <div class="col-md-4">
                <div class="portlet light profile-sidebar-portlet bordered">
                    <div class="profile-userpic">
                        <div style="margin: auto;width: 50%">
                            <img src="<?php echo e(asset('img/profiles').'/'.($user->images?($user->images[0]->url??'default.png'):'default.png')); ?>" class="img-responsive" alt="">
                            <form action="/change-profile" method="post" enctype="multipart/form-data" id="change_image_form">
                               <?php echo csrf_field(); ?>
                                <input type="file" name="profile" class="custom-file-input" title="Change profile image" id="profile-img">
                            </form>
                        </div>
                    </div>
                    <div class="profile-usertitle">
                        <div class="profile-usertitle-name"> <?php echo e($user->name); ?> </div>
                        <div class="profile-usertitle-job"> <?php echo e(trans('strings.'.$user->role)); ?> </div>
                    </div>
                    <div class="profile-userbuttons">
                        <button type="button" id="follow"
                                class="btn follow-btn btn-sm"><?php echo e($isFollow?trans('strings.unfollow'):trans('strings.follow')); ?>

                            (<?php echo e($user->followers_count??count($followers)); ?>)
                        </button>
                        <button type="button" class="btn btn-info btn-sm"><?php echo app('translator')->getFromJson('strings.message'); ?></button>
                    </div>
                    <div class="profile-usermenu">
                        <?php if(auth()->user()&&!isset($followers)): ?>
                            <ul class="nav">
                                <li>
                                    <a href="/report/<?php echo e($user->slug); ?>">
                                        <?php echo app('translator')->getFromJson('strings.report'); ?>
                                    </a>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="portlet light bordered">
                    <div class="portlet-title tabbable-line">
                        <div class="caption caption-md" style="<?php echo e(app()->getLocale()=='ar'?'float: right;':''); ?>">
                            <i class="icon-globe theme-font hide"></i>
                            <span class="caption-subject font-blue-madison bold uppercase"><?php echo app('translator')->getFromJson('strings.profile_info'); ?></span>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div>

                            <!-- Nav tabs -->
                            <?php if(auth()->user()&&isset($followers)): ?>
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#" id="update_btn"><?php echo app('translator')->getFromJson('strings.update'); ?></a>
                                </li>
                            </ul>
                            <div class="tab-content" id="update_data" style="display: none;">
                                <div role="tabpanel" class="tab-pane active" id="home">
                                    <form action="/reg/<?php echo e($user->slug); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('put')); ?>

                                        <div class="row">
                                            <div class="col-sm-12">
                                                <label><?php echo app('translator')->getFromJson('strings.name'); ?></label>
                                                <input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($user->name); ?>">
                                            </div>
                                            <div class="col-sm-12">
                                                <label><?php echo app('translator')->getFromJson('strings.old_password'); ?></label>
                                                <input type="password" class="form-control <?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" name="old_password">
                                            </div>
                                            <div class="col-sm-6">
                                                <label><?php echo app('translator')->getFromJson('strings.password'); ?></label>
                                                <input type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
                                            </div>
                                            <div class="col-sm-6">
                                                <label><?php echo app('translator')->getFromJson('strings.password_confirm'); ?></label>
                                                <input type="password" class="form-control <?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation">
                                            </div>
                                            <div class="col-sm-12">
                                                <label><?php echo app('translator')->getFromJson('strings.age'); ?></label>
                                                <input type="date" class="form-control <?php echo e($errors->has('age') ? ' is-invalid' : ''); ?>" name="age" value="<?php echo e($user->age); ?>">
                                            </div>
                                            <div class="col-sm-6">
                                                <label><?php echo app('translator')->getFromJson('strings.phone'); ?></label>
                                                <input type="text" class="form-control <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.optional'); ?>" name="phone" value="<?php echo e($user->phone); ?>">
                                            </div>
                                            <div class="col-sm-6">
                                                <label><?php echo app('translator')->getFromJson('strings.account_type'); ?></label>
                                                <select class="form-control" name="role">
                                                    <option value="user" <?php echo e($user->role=='user'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.user'); ?></option>
                                                    <option value="developer" <?php echo e($user->role=='developer'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.developer'); ?></option>
                                                    <option value="broker" <?php echo e($user->role=='broker'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.broker'); ?></option>
                                                    <option value="owner" <?php echo e($user->role=='owner'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.owner'); ?></option>
                                                    <option value="renter" <?php echo e($user->role=='renter'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.renter'); ?></option>
                                                    <option value="engineer" <?php echo e($user->role=='engineer'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.engineer'); ?></option>
                                                    <option value="contractor" <?php echo e($user->role=='contractor'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.contractor'); ?></option>
                                                    <option value="corporation" <?php echo e($user->role=='corporation'?'selected':''); ?>><?php echo app('translator')->getFromJson('strings.corporation'); ?></option>
                                                </select>
                                            </div>
                                            <div class="col-sm-12" style="margin-top:20px;">
                                                <button class="btn btn-white" type="submit"><?php echo app('translator')->getFromJson('strings.save'); ?></button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                                <script>
                                    $('#update_btn').click(function (){
                                        $('#update_data').toggle();
                                        $('#user_data').toggle();
                                    });
                                </script>
                            <?php endif; ?>
                            <div class="tab-content" id="user_data">
                                <div role="tabpanel" class="tab-pane active" id="home">
                                    <p><?php echo app('translator')->getFromJson('strings.name'); ?>: <?php echo e($user->name); ?></p>
                                    <p><?php echo app('translator')->getFromJson('strings.email'); ?>: <?php echo e($user->email); ?></p>
                                    <p><?php echo app('translator')->getFromJson('strings.phone'); ?>: <?php echo e($user->phone); ?></p>
                                    <p><?php echo app('translator')->getFromJson('strings.age'); ?>: <?php echo e($user->age); ?></p>
                                    <p><?php echo app('translator')->getFromJson('strings.joint_from'); ?>: <?php echo e($user->created_at); ?></p>
                                    <p><?php echo app('translator')->getFromJson('strings.global_link'); ?>: <a
                                                href="/profiles/<?php echo e($user->slug); ?>"><?php echo e(request()->getHost()); ?>/profiles/<?php echo e($user->slug); ?></a></p>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="portlet light bordered">
                    <div class="portlet-title tabbable-line">
                        <div class="caption caption-md " style="<?php echo e(app()->getLocale()=='ar'?'float: right;':''); ?>">
                            <i class="icon-globe theme-font hide"></i>
                            <span class="caption-subject font-blue-madison bold uppercase"><?php echo app('translator')->getFromJson('strings.posts'); ?></span>
                        </div>
                    </div>
                    <div class="portlet-body">
                        <div>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="home">
                                    <?php if(isset($followers)): ?>
                                        <form action="/posts" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <textarea class="form-control" name="post"
                                                      placeholder="<?php echo app('translator')->getFromJson('strings.type_post'); ?>"></textarea>
                                            <br>
                                            <input type="file" name="images[]" class="custom-file-input" multiple
                                                   accept="image/gif, image/jpeg, image/png" id="post-img">
                                            <br><br>
                                            <button type="submit"
                                                    class="btn follow-btn btn-sm"><?php echo app('translator')->getFromJson('strings.send'); ?></button>
                                            <div id="images">

                                            </div>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card post">
                            <div class="row">
                                <img src="<?php echo e(asset('img/profiles').'/'.($post->users->images?($post->users->images[0]->url??'default.png'):'default.png')); ?>" class="post-img">
                                <span class="post-name"><?php echo e($post->users->name); ?><p class="post-name-tiny">(<?php echo e($post->created_at); ?>) <span class="post-follow">Follow</span></p></span>
                            </div>
                            <hr>
                            <p class="post-body"><?php echo e($post->content); ?></p>
                            <hr>
                            <div class="row">
                                <?php $__currentLoopData = $post->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <img src="<?php echo e(asset('img/posts').'/'.$image->url); ?>" width="100%" height="200px" style="padding: 10px;">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <hr>
                            <div class="row" style="width:80%;margin: auto;">
                                <?php $isliked=$isdislike=false;$likescount=$dislikescount=0 ?>

                                <?php $__currentLoopData = $post->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()): ?>
                                        <?php if($like->user_id==auth()->user()->id&&$like->type==1): ?>
                                            <?php $isliked=true; ?>
                                            <?php break; ?>;
                                        <?php elseif($like->user_id==auth()->user()->id&&$like->type==0): ?>
                                            <?php $isdislike=true; ?>
                                            <?php break; ?>;
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <a class="col-sm-3" href="/like-post/<?php echo e($post->slug); ?>"><i class="fa fa-thumbs<?php echo e($isliked?'':'-o'); ?>-up"></i> <?php echo app('translator')->getFromJson('strings.like'); ?> (<?php echo e($likes[$post->id]); ?>)</a>
                                <a class="col-sm-3" href="/dislike-post/<?php echo e($post->slug); ?>"><i class="fa fa-thumbs<?php echo e($isdislike?'':'-o'); ?>-down"></i> <?php echo app('translator')->getFromJson('strings.dislike'); ?> (<?php echo e($dislikes[$post->id]); ?>)</a>
                                <div class="col-sm-6" style="cursor: pointer" id="comment_btn<?php echo e($post->slug); ?>"><i class="fa fa-comment"></i> <?php echo app('translator')->getFromJson('strings.comment'); ?>(<?php echo e(count($post->comments)); ?>)</div>
                                <br><br>
                                <div class="col-sm-12" id="comment_tab<?php echo e($post->slug); ?>" style="display: none;">
                                    <?php if(auth()->user()): ?>
                                        <form action="/posts/comment/<?php echo e($post->slug); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="text" name="comment" class="form-control">
                                            <button class="btn btn-primary" style="margin: 5px 0;" type="submit"><?php echo app('translator')->getFromJson('strings.comment'); ?></button>
                                        </form>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $isliked=$isdislike=false; ?>
                                        <?php $__currentLoopData = $comment->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(auth()->user()): ?>
                                                <?php if($like->user_id==auth()->user()->id&&$like->type==1): ?>
                                                    <?php $isliked=true; ?>
                                                    <?php break; ?>;
                                                <?php elseif($like->user_id==auth()->user()->id&&$like->type==0): ?>
                                                    <?php $isdislike=true; ?>
                                                    <?php break; ?>;
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <img src="<?php echo e(asset('img/profiles').'/'.($comment->user->images?($comment->user->images[0]->url??'default.png'):'default.png')); ?>" class="comment-img">
                                                <span class="comment-name"><?php echo e($comment->user->name); ?>

							<p> <?php echo e($comment->comment); ?></p>
						</span>
                                            </div>
                                            <div class="col-sm-12 mx-1">
                                                <div class="row">
                                                    <a class="col-sm-3" href="/like-comment/<?php echo e($comment->id); ?>"><i class="fa fa-thumbs<?php echo e($isliked?'':'-o'); ?>-up"></i> <?php echo app('translator')->getFromJson('strings.like'); ?> (<?php echo e($commentlikes[$post->id][$comment->id]); ?>)</a>
                                                    <a class="col-sm-3" href="/dislike-comment/<?php echo e($comment->id); ?>"><i class="fa fa-thumbs<?php echo e($isdislike?'':'-o'); ?>-down"></i> <?php echo app('translator')->getFromJson('strings.dislike'); ?> (<?php echo e($commentdislikes[$post->id][$comment->id]); ?>)</a>
                                                    <div class="col-sm-6" style="cursor: pointer" id="reply_btn<?php echo e($comment->id); ?>"><i class="fa fa-comment"></i> <?php echo app('translator')->getFromJson('strings.reply'); ?>(<?php echo e(count($comment->replies)); ?>)</div>
                                                    <div class="col-sm-12" id="reply_tab<?php echo e($comment->id); ?>" style="display: none;">
                                                        <?php if(auth()->user()): ?>
                                                            <form action="/comments/reply/<?php echo e($comment->id); ?>" method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="text" name="reply" class="form-control">
                                                                <button class="btn btn-primary" style="margin: 5px 0;" type="submit"><?php echo app('translator')->getFromJson('strings.reply'); ?></button>
                                                            </form>
                                                        <?php endif; ?>
                                                        <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $isliked=$isdislike=false; ?>
                                                            <?php $__currentLoopData = $reply->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(auth()->user()): ?>
                                                                    <?php if($like->user_id==auth()->user()->id&&$like->type==1): ?>
                                                                        <?php $isliked=true; ?>
                                                                        <?php break; ?>;
                                                                    <?php elseif($like->user_id==auth()->user()->id&&$like->type==0): ?>
                                                                        <?php $isdislike=true; ?>
                                                                        <?php break; ?>;
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="row">
                                                                <div class="col-sm-12">
                                                                    <img src="<?php echo e(asset('img/profiles').'/'.($reply->user->images?($reply->user->images[0]->url??'default.png'):'default.png')); ?>" class="comment-img">
                                                                    <span class="comment-name"><?php echo e($reply->user->name); ?>

												<p> <?php echo e($reply->reply); ?></p>
											</span>
                                                                </div>
                                                                <div class="col-sm-8 mx-1">
                                                                    <div class="row">
                                                                        <a class="col-sm-6" href="/like-reply/<?php echo e($reply->id); ?>"><i class="fa fa-thumbs<?php echo e($isliked?'':'-o'); ?>-up"></i> <?php echo app('translator')->getFromJson('strings.like'); ?> (<?php echo e($replieslikes[$post->id][$comment->id][$reply->id]); ?>)</a>
                                                                        <a class="col-sm-6" href="/dislike-reply/<?php echo e($reply->id); ?>"><i class="fa fa-thumbs<?php echo e($isdislike?'':'-o'); ?>-down"></i> <?php echo app('translator')->getFromJson('strings.dislike'); ?> (<?php echo e($repliesdislikes[$post->id][$comment->id][$reply->id]); ?>)</a>
                                                                    </div>
                                                                </div>
                                                                <hr>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                        </div>
                                        <script>
                                            $('#reply_btn<?php echo e($comment->id); ?>').click(function () {
                                                $('#reply_tab<?php echo e($comment->id); ?>').toggle();
                                            });
                                        </script>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <br>
                        <script>
                            $('#comment_btn<?php echo e($post->slug); ?>').click(function () {
                                $('#comment_tab<?php echo e($post->slug); ?>').toggle();
                            });
                        </script>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- // End Page Content -->
    <script>
        $('#follow').click(function () {
            location.href = '/follow/<?php echo e($user->slug); ?>';
        });
        $('#profile-img').change(function () {
            $('#change_image_form').submit();
        });
        function readURL(input) {
            $('#images').html('');
            var files = event.target.files; //FileList object
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                //Only pics
                if (!file.type.match('image')) continue;

                var picReader = new FileReader();
                picReader.addEventListener("load", function (event) {
                    var picFile = event.target;
                    $('#images').append('<img src="' + picFile.result + '" class="showimg">');
                });
                //Read the image
                picReader.readAsDataURL(file);
            }
        }

        $("#post-img").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/profile.blade.php ENDPATH**/ ?>