<?php $__env->startSection('content'); ?>
<!-- Page Content-->
<h3 class="title"> <?php echo app('translator')->getFromJson('strings.register'); ?></h3>
<div class="form-group loginform">
	<?php if(count($errors)>0): ?>
    <br>
    <div class="alert alert-danger <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
      <?php $a=[]; $a=session()->pull('m'); ?>
      <div class="alert alert-<?php echo e($a[0]); ?> <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>" style="width: 40%">
        <?php echo e($a[1]); ?>

      </div>
    <?php endif; ?>
    <form action="/reg" method="post">
		<?php echo csrf_field(); ?>
		<div class="row <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.name'); ?></label>
				<input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.email'); ?></label>
				<input type="text" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="example@example.com" name="email" value="<?php echo e(old('email')); ?>">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.password'); ?></label>
				<input type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.password_confirm'); ?></label>
				<input type="password" class="form-control <?php echo e($errors->has('password_confirmation') ? ' is-invalid' : ''); ?>" name="password_confirmation">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.age'); ?></label>
				<input type="date" class="form-control <?php echo e($errors->has('age') ? ' is-invalid' : ''); ?>" name="age">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.phone'); ?></label>
				<input type="text" class="form-control <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.optional'); ?>" name="phone">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.account_type'); ?></label>
				<select class="form-control" name="role">
					<option value="user"><?php echo app('translator')->getFromJson('strings.user'); ?></option>
					<option value="developer"><?php echo app('translator')->getFromJson('strings.developer'); ?></option>
					<option value="broker"><?php echo app('translator')->getFromJson('strings.broker'); ?></option>
					<option value="owner"><?php echo app('translator')->getFromJson('strings.owner'); ?></option>
					<option value="renter"><?php echo app('translator')->getFromJson('strings.renter'); ?></option>
					<option value="engineer"><?php echo app('translator')->getFromJson('strings.engineer'); ?></option>
					<option value="contractor"><?php echo app('translator')->getFromJson('strings.contractor'); ?></option>
					<option value="corporation"><?php echo app('translator')->getFromJson('strings.corporation'); ?></option>
				</select>
			</div>
			<div class="col-sm-12" style="margin-top:20px;">
				<button class="btn btn-white" type="submit"><?php echo app('translator')->getFromJson('strings.register'); ?></button>
			</div>
		</div>
	</form>
</div>
<!-- // End Page Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/reg.blade.php ENDPATH**/ ?>