<?php $__env->startSection('content'); ?>
<?php if(count($errors)>0): ?>
<div class="alert alert-danger <?php echo e(!session()->has('lang')?'ar':''); ?>">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(Session::has('m')): ?>
  <?php $a=[]; $a=session()->pull('m'); ?>
  <div class="alert alert-<?php echo e($a[0]); ?> <?php echo e(!session()->has('lang')?'ar':''); ?>" style="width: 40%">
    <?php echo e($a[1]); ?>

  </div>
<?php endif; ?>
<!-- Page Content-->
<h3 class="title"><?php echo app('translator')->getFromJson('strings.personal_data'); ?></h3>
<?php if(auth::user()): ?>
<p class="title">
	تريد ان تظهر نفس بياناتك الشخصية السابقة ؟
	<br>
	<input type="radio" id="same" name="data" value="0" checked> لا
	<input type="radio" id="nosame" name="data" value="1"> نعم
</p>
<hr>
<?php endif; ?>
<form action="/addpro/<?php echo e($adid); ?>" method="post">
	<?php echo csrf_field(); ?>
	<div class="form-group loginform">
		<div class="row <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.name'); ?></label>
				<input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" id="name" required value="<?php echo e(Auth::user()?Auth::user()->name:old('name')); ?>">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.phone'); ?></label>
				<input type="text" class="form-control <?php echo e($errors->has('phone') ? ' is-invalid' : ''); ?>" name="phone" id="phone" required value="<?php echo e(Auth::user()?Auth::user()->phone:old('phone')); ?>">
			</div>
			<div class="col-sm-12">
				<label><?php echo app('translator')->getFromJson('strings.email'); ?></label>
				<input type="text" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="example@example.com" name="email" id="email" value="<?php echo e(Auth::user()?Auth::user()->email:old('email')); ?>">
				<input type="checkbox" name="showemail" id="showemail"> <?php echo app('translator')->getFromJson('strings.show_email'); ?>
			</div>
			<div class="col-sm-12" style="margin-top:20px;">
				<div class="btn btn-white" id="review"><?php echo app('translator')->getFromJson('strings.review'); ?></div>
				<button class="btn btn-white" type="submit"><?php echo app('translator')->getFromJson('strings.publish'); ?></button>
			</div>
		</div>
	</div>
</form>
<!-- // End Page Content -->
<script type="text/javascript">
	$('#review').click(function(){
		if($('#name').val()==''||$('#phone').val()==''){
			<?php if(Session::has('lang')): ?>
			alert('Error : You Must Complete Data First');
			<?php else: ?>
			alert('خطأ : عليك إكمال البيانات');
			<?php endif; ?>
		}else{
			if($('#showemail').prop("checked")==true){
				window.open(
				  '<?php echo e(Request::root()); ?>/review/<?php echo e($adid); ?>?name='+$('#name').val()+'&phone='+$('#phone').val()+'&email='+$('#email').val(),
				  '_blank'
				);
			}else{
				window.open(
				  '<?php echo e(Request::root()); ?>/review/<?php echo e($adid); ?>?name='+$('#name').val()+'&phone='+$('#phone').val(),
				  '_blank'
				);
			}
		}
	});
	<?php if(Auth::user()): ?>
	$('#nosame').click(function(){
		$('#name').val('');
		$('#phone').val('');
		$('#email').val('');
	});
	$('#same').click(function(){
		$('#name').val('<?php echo e(Auth::user()->name); ?>');
		$('#phone').val('<?php echo e(Auth::user()->phone); ?>');
		$('#email').val('<?php echo e(Auth::user()->email); ?>');
	});
	<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/adpro.blade.php ENDPATH**/ ?>