<?php $__env->startSection('content'); ?>
<!-- Page Content-->
<h3 class="title"><?php echo app('translator')->getFromJson('strings.contact'); ?></h3>
<div class="form-group contactform">
	<?php if(count($errors)>0): ?>
    <br>
    <div class="alert alert-danger <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
      <?php $a=[]; $a=session()->pull('m'); ?>
      <div class="alert alert-<?php echo e($a[0]); ?> <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>" style="width: 40%">
        <?php echo e($a[1]); ?>

      </div>
    <?php endif; ?>
	<form action="/sendmes" method="post">
		<?php echo csrf_field(); ?>
		<div class="row <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.name'); ?>:</label>
				<input type="text" class="form-control <?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.enter_name'); ?>" name="name" value="<?php echo e(Auth::user()?Auth::user()->name:''); ?>">
			</div>
			<div class="col-sm-6">
				<label><?php echo app('translator')->getFromJson('strings.email'); ?>:</label>
				<input type="text" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.your_email'); ?>" name="email" value="<?php echo e(Auth::user()?Auth::user()->email:''); ?>">
			</div>
			<div class="col-sm-12">
				<label><?php echo app('translator')->getFromJson('strings.subject'); ?>:</label>
				<input type="text" class="form-control <?php echo e($errors->has('subject') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.how_help'); ?>" name="subject">
			</div>
			<div class="col-sm-12">
				<label><?php echo app('translator')->getFromJson('strings.message'); ?>:</label>
				<textarea type="text" class="form-control <?php echo e($errors->has('message') ? ' is-invalid' : ''); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.details'); ?>.." rows="4" name="message"></textarea>
			</div>
			<button type="submit" class="btn button-theme btn-search btn-block col-sm-2" style="margin-top:20px;margin-right:30px;">
				<i class="fa fa-envelope"></i><strong> <?php echo app('translator')->getFromJson('strings.send'); ?> </strong>
			</button>
		</div>

	</form>
</div>
<!-- // End Page Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/contact.blade.php ENDPATH**/ ?>