<?php $__env->startSection('content'); ?>
<div id="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="/admindb">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Messages</li>
      </ol>

    <!-- Page Content -->
    <?php if(count($errors)>0): ?>
    <br>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
      <?php $a=[]; $a=session()->pull('m'); ?>
      <div class="alert alert-<?php echo e($a[0]); ?>" style="width: 40%">
        <?php echo e($a[1]); ?>

      </div>
    <?php endif; ?>
    <!-- Page Content -->
        <div class="container">
          <div class="card-body">
                <div class="list-group">
                  <?php $__currentLoopData = $newmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="cursor: pointer" data-toggle="collapse" data-target="#mes<?php echo e($m->id); ?>" class="list-group-item"><b>New Message from : <?php echo e($m->name); ?> (<?php echo e($m->email); ?>) with subject : <?php echo e($m->subject); ?></b>/ <?php echo e($m->date); ?></a>
                <div id="mes<?php echo e($m->id); ?>" class="collapse">
                <?php echo e($m->message); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $oldmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="cursor: pointer" data-toggle="collapse" data-target="#mes<?php echo e($m->id); ?>" class="list-group-item">Message from : <?php echo e($m->name); ?> (<?php echo e($m->email); ?>) with subject : <?php echo e($m->subject); ?>/ <?php echo e($m->date); ?></a>
                <div id="mes<?php echo e($m->id); ?>" class="collapse">
                <?php echo e($m->message); ?>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
          </div>
          </div>
        </div>
  </div>
  <!-- /.content-wrapper -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/admin/messages.blade.php ENDPATH**/ ?>