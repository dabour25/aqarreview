<?php $__env->startSection('content'); ?>
<div id="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="/admindb">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Approve Advertises</li>
      </ol>

    <!-- Page Content -->
    <?php if(count($errors)>0): ?>
    <br>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
      <?php $a=[]; $a=session()->pull('m'); ?>
      <div class="alert alert-<?php echo e($a[0]); ?>" style="width: 40%">
        <?php echo e($a[1]); ?>

      </div>
    <?php endif; ?>
    <!-- Page Content -->
        <div class="container">
          <div class="card-body">
                <div class="list-group">
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="cursor: pointer" data-toggle="collapse" data-target="#ad<?php echo e($ad->id); ?>" class="list-group-item"><b>New Advertise : <?php echo e($ad->title); ?></b></a>
                <div id="ad<?php echo e($ad->id); ?>" class="collapse">
                  <a href="/admindb/review/<?php echo e($ad->id); ?>" class="btn btn-success" target="blank">Review</a>
                  <a href="/admindb/approvea/<?php echo e($ad->id); ?>" class="btn btn-primary">Approve</a>
                  <a href="/admindb/removead/<?php echo e($ad->id); ?>" class="btn btn-danger">Remove</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $oldads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a style="cursor: pointer" data-toggle="collapse" data-target="#ad<?php echo e($oad->id); ?>" class="list-group-item">
                Advertise : <?php echo e($oad->title); ?> Still not Approved</a>
                <div id="ad<?php echo e($oad->id); ?>" class="collapse">
                  <a href="/admindb/review/<?php echo e($oad->id); ?>" class="btn btn-success" target="blank">Review</a>
                  <a href="/admindb/approvea/<?php echo e($oad->id); ?>" class="btn btn-primary">Approve</a>
                  <a href="/admindb/removead/<?php echo e($oad->id); ?>" class="btn btn-danger">Remove</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
          </div>
          <?php echo e($oldads->links()); ?>

          </div>
        </div>
  </div>
  <!-- /.content-wrapper -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/admin/approve.blade.php ENDPATH**/ ?>