<?php $__env->startSection('content'); ?>
<?php if(count($errors)>0): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(Session::has('m')): ?>
  <?php $a=[]; $a=session()->pull('m'); ?>
  <div class="alert alert-<?php echo e($a[0]); ?>" style="width: 40%">
    <?php echo e($a[1]); ?>

  </div>
<?php endif; ?>
<?php if(!Session::has('lang')): ?>
<!-- Page Content-->
<h1 class="title" style="padding-top:150px;padding-bottom:150px;">خطأ 404 الصفحة غير موجودة</h1>
<!-- // End Page Content -->
<?php else: ?>
<!-- Page Content-->
<h1 class="title" style="padding-top:150px;padding-bottom:150px;">Error 404 Page Not Found</h1>
<!-- // End Page Content -->
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/errors/404.blade.php ENDPATH**/ ?>