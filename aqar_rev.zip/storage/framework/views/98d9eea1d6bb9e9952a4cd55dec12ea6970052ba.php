<?php $__env->startSection('content'); ?>
<?php if(count($errors)>0): ?>
<div class="alert alert-danger <?php echo e(!session()->has('lang')?'ar':''); ?>">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(Session::has('m')): ?>
  <?php $a=[]; $a=session()->pull('m'); ?>
  <div class="alert alert-<?php echo e($a[0]); ?>" style="width: 40%">
    <?php echo e($a[1]); ?>

  </div>
<?php endif; ?>
<!-- Page Content-->
<h3 class="title"><?php echo e($ad->title); ?></h3>
<div class="row <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>" style="padding:10px;">
	<div id="carouselExampleIndicators" class="carousel slide col-md-6" data-ride="carousel">
	  <div class="carousel-inner">
		<div class="carousel-item active">
			<?php if($ad->image==''): ?>
			<img class="d-block w-100" src="<?php echo e(asset('img/ads')); ?>/<?php echo e($links[5]->value); ?>" alt="Primary slide" style="height: 600px;object-fit: contain">
			<?php else: ?>
		  <img class="d-block w-100 zoomimg" src="<?php echo e(asset('img/ads')); ?>/<?php echo e($ad->image); ?>" alt="Primary slide" style="height: 600px;object-fit: contain" id="fim">
		  <?php endif; ?>
		</div>
		<div id="fmodal" class="modal">
			  <span class="close" id="fclose">&times;</span>
			  <img class="modal-content" id="fimg" style="object-fit: contain">
			</div>
		  <script>
			var fmodal = document.getElementById("fmodal");
			var fimg = document.getElementById("fim");
			var fmodalImg = document.getElementById("fimg");
			fimg.onclick = function(){
			  fmodal.style.display = "block";
			  fmodalImg.src = this.src;
			}

			var fspan = document.getElementById("fclose");

			fspan.onclick = function() {
			  fmodal.style.display = "none";
			}
		  </script>
		<?php $imgs=explode('|', $ad->images); ?>
		<?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($im!=''): ?>
		<div class="carousel-item">
		  <img class="d-block w-100 zoomimg" id="im<?php echo e($k); ?>" src="<?php echo e(asset('img/ads')); ?>/<?php echo e($im); ?>" alt="<?php echo e($ad->title); ?>">
		</div>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  </div>
	  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	  </a>
	  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	  </a>
	</div>
	<?php $__currentLoopData = $imgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$im): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($im!=''): ?>
	<!-- The Modal -->
			<div id="modal<?php echo e($k); ?>" class="modal">
			  <span class="close" id="close<?php echo e($k); ?>">&times;</span>
			  <img class="modal-content" id="img<?php echo e($k); ?>" style="object-fit: contain">
			</div>
		<script>
		var modal<?php echo e($k); ?> = document.getElementById("modal<?php echo e($k); ?>");
		var img<?php echo e($k); ?> = document.getElementById("im<?php echo e($k); ?>");
		var modalImg<?php echo e($k); ?> = document.getElementById("img<?php echo e($k); ?>");
		img<?php echo e($k); ?>.onclick = function(){
		  modal<?php echo e($k); ?>.style.display = "block";
		  modalImg<?php echo e($k); ?>.src = this.src;
		}

		var span<?php echo e($k); ?> = document.getElementById("close<?php echo e($k); ?>");

		span<?php echo e($k); ?>.onclick = function() {
		  modal<?php echo e($k); ?>.style.display = "none";
		}
		</script>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<div class="col-md-6" style="padding:50px;">
		<h6>
			<b style="color:#ddbd25;"><?php echo app('translator')->getFromJson('strings.price'); ?>:</b>
			<p class="details-ar"><?php echo e($ad->price); ?><?php echo app('translator')->getFromJson('strings.le'); ?></p>
		</h6>
		<h6>
			<b style="color:#ddbd25;"><?php echo app('translator')->getFromJson('strings.description'); ?>:</b>
			<p class="details-ar"><?php echo e($ad->description); ?></p>
		</h6>
		<h6>
			<b style="color:#ddbd25;"><?php echo app('translator')->getFromJson('strings.other_details'); ?>:</b>
			<div class="property-box">
				<div class="detail" style="margin:0;box-shadow:0 0 0;">
					<ul class="facilities-list clearfix">
						<?php if($ad->type==3): ?>
						<li>
							<i class="flaticon-ui"></i><?php echo app('translator')->getFromJson('strings.area'); ?> : <?php echo e($ad->size); ?> <?php echo app('translator')->getFromJson('strings.meter'); ?>
						</li>
						<?php else: ?>
						<li>
							<i class="flaticon-bed"></i><?php echo app('translator')->getFromJson('strings.rooms'); ?> : <?php echo e($ad->rooms); ?>

						</li>
						<li>
							<i class="flaticon-bathroom"></i><?php echo app('translator')->getFromJson('strings.bathrooms'); ?> : <?php echo e($ad->pathroom); ?>/<?php echo app('translator')->getFromJson('strings.kitchens'); ?> : <?php echo e($ad->kitchen); ?>

						</li>
						<li>
							<i class="flaticon-ui"></i><?php echo app('translator')->getFromJson('strings.area'); ?> : <?php echo e($ad->size); ?> <?php echo app('translator')->getFromJson('strings.meter'); ?>
						</li>
						<li>
							<i class="flaticon-car"></i><?php echo e($ad->parking==1?trans('strins.park'):trans('strings.no_park')); ?>

						</li>
						<li>
							<i class="fa fa-building"></i><?php echo app('translator')->getFromJson('strings.floor'); ?> : <?php echo e($ad->floor); ?>

						</li>
						<li>
							<i class="fa fa-leaf"></i><?php echo app('translator')->getFromJson('strings.finishing'); ?> :
							<?php if($ad->finish==1): ?>
								<?php echo app('translator')->getFromJson('strings.full'); ?>
							<?php elseif($ad->finish==2): ?>
								<?php echo app('translator')->getFromJson('strings.not_full'); ?>
							<?php else: ?>
								<?php echo app('translator')->getFromJson('strings.red_brick'); ?>
							<?php endif; ?>
						</li>
						<li>
							<i class="fa fa-gamepad"></i><?php echo app('translator')->getFromJson('strings.furniture'); ?> : <?php echo e($ad->furniture==1?trans('strings.yes'):trans('strings.no')); ?>

						</li>
						<?php endif; ?>
						<li>
							<i class="fa fa-map-marker"></i><?php echo e($ad->address); ?>

						</li>
					</ul>
				</div>
			</div>
		</h6>
		<div class="row">
			<?php if(Auth::user()&&Auth::user()->id==$ad->user): ?>
			<a href="/removead/<?php echo e($ad->id); ?>" class="btn button-theme btn-search btn-block col-sm-5" >
				<i class="fa fa-trash"></i><strong><?php echo app('translator')->getFromJson('strings.remove_ad'); ?></strong>
			</a>
			<?php elseif(Auth::user()): ?>
			<button class="btn button-theme btn-search btn-block col-sm-5" id="favo<?php echo e($ad->id); ?>" 
				<?php echo e($page=="REVIEW ADVERTISE"?'disabled':''); ?>>
				<?php if(empty($fav)): ?>
                <i class="fa fa-star" id="fav<?php echo e($ad->id); ?>"><strong> <?php echo app('translator')->getFromJson('strings.add_to_favourites'); ?> </strong></i>
                <?php else: ?>
                <i class="fa fa-star" id="fav<?php echo e($ad->id); ?>"><strong><?php echo app('translator')->getFromJson('strings.remove_from_favourites'); ?></strong></i>
                <?php endif; ?>
			</button>
			<?php else: ?>
			<button class="btn button-theme btn-search btn-block col-sm-5" disabled>
				<i class="fa fa-star"></i><strong> <?php echo app('translator')->getFromJson('strings.add_to_favourites'); ?> </strong>
			</button>
			<?php endif; ?>
			<div class="col-sm-1"></div>
			<button class="btn button-theme btn-search btn-block col-sm-5" data-toggle="collapse" data-target="#sellerdata" aria-expanded="false" aria-controls="sellerdata">
				<i class="fa fa-address-book"></i><strong><?php echo app('translator')->getFromJson('strings.show_advertiser_data'); ?></strong>
			</button>
		</div>
		<br>
		<div class="collapse" id="sellerdata">
		  	<div class="card card-body">
		    	<p><strong><?php echo app('translator')->getFromJson('strings.name'); ?>: </strong><?php echo e($name); ?></p>
		    	<p><strong><?php echo app('translator')->getFromJson('strings.phone'); ?>: </strong><?php echo e($phone); ?></p>
		    	<?php if(isset($email)&&$email!=''): ?>
		    	<p><strong> <?php echo app('translator')->getFromJson('strings.email'); ?>: </strong><?php echo e($email); ?></p>
		    	<?php endif; ?>
		  	</div>
		</div>
	</div>
</div>
<script type="text/javascript">
    $('#favo<?php echo e($ad->id); ?>').click(function(){
        $.ajax({
           type:'GET',
           url:'/fav/<?php echo e($ad->id); ?>',
           success:function(data) {
                if(data.type==1){
                    $('#fav<?php echo e($ad->id); ?>').html('<strong><?php echo app('translator')->getFromJson('strings.remove_from_favourites'); ?></strong>');
                }else if(data.type==2){
                    $('#fav<?php echo e($ad->id); ?>').html('<strong><?php echo app('translator')->getFromJson('strings.add_to_favourites'); ?></strong>');
                }
                alert(data.msg);
           }
        });
    });
</script>
<!-- // End Page Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/single.blade.php ENDPATH**/ ?>