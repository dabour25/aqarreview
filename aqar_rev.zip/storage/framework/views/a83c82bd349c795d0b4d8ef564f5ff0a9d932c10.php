<?php $__env->startSection('content'); ?>
<div id="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="/admindb">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Control Advertises</li>
      </ol>

    <!-- Page Content -->
    <?php if(count($errors)>0): ?>
    <br>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
      <?php $a=[]; $a=session()->pull('m'); ?>
      <div class="alert alert-<?php echo e($a[0]); ?>" style="width: 40%">
        <?php echo e($a[1]); ?>

      </div>
    <?php endif; ?>
    <!-- Page Content -->
        <div class="container">
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-dark">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Review</th>
                    <th scope="col">Remove</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($k+1); ?></th>
                    <td><?php echo e($a->title); ?></td>
                    <td><?php echo e($a->name); ?></td>
                    <td><?php echo e($a->email); ?></td>
                    <td><a href="/admindb/review/<?php echo e($a->adid); ?>" class="btn btn-success" target="blank">Review</a></td>
                    <td><a href="/admindb/removead/<?php echo e($a->adid); ?>" class="btn btn-danger">X</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
          <?php echo e($ads->links()); ?>

        </div>
        </div>
      </div>

  </div>
  <!-- /.content-wrapper -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/admin/adscontrol.blade.php ENDPATH**/ ?>