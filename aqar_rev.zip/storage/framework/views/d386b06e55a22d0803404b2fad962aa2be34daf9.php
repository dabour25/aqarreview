<?php $__env->startSection('content'); ?>
<!-- Banner start -->
<div class="banner" id="banner">
    <div id="bannerCarousole" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner banner-slider-inner text-left">
            <div class="carousel-item banner-max-height active">
                <img class="d-block w-100 h-100" src="<?php echo e(asset('img/banner/banner-1.jpg')); ?>" alt="banner">
            </div>
            <div class="carousel-item banner-max-height">
                <img class="d-block w-100 h-100" src="<?php echo e(asset('img/banner/banner-3.jpg')); ?>" alt="banner">
            </div>
            <div class="carousel-item banner-max-height">
                <img class="d-block w-100 h-100" src="<?php echo e(asset('img/banner/banner-2.jpg')); ?>" alt="banner">
            </div>
            <div class="carousel-content container banner-info-2 bi-3 text-center">
                <h3><?php echo app('translator')->getFromJson('strings.home_here'); ?></h3>
                <p><?php echo app('translator')->getFromJson('strings.real_state'); ?></p>
                <a href="#" class="btn btn-white btn-read-more"><?php echo app('translator')->getFromJson('strings.read_more'); ?></a>
            </div>
        </div>
        <!-- Search area 3 start -->
            <div class="search-area-5 <?php echo e(app()->getLocale()=="ar"?"ar":""); ?>">
                <div class="container">
                    <div class="inline-search-area">
                        <div class="row">
    						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group">
                                <input type="text" class="form-control" placeholder="<?php echo app('translator')->getFromJson('strings.search_string'); ?>"   id="search">
                            </div>
    						<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group">
                                <select class="selectpicker search-fields" id="type">
                                    <option value="all" class="ar"><?php echo app('translator')->getFromJson('strings.type'); ?></option>
                                    <option value="1" class="ar"><?php echo app('translator')->getFromJson('strings.buy'); ?></option>
                                    <option value="2" class="ar"><?php echo app('translator')->getFromJson('strings.rent'); ?></option>
                                </select>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group">
                                <div class="range-slider">
                                    <div data-min="0" data-max="10000000"  data-min-name="min" data-max-name="max" data-unit="<?php echo app('translator')->getFromJson('strings.le'); ?>" class="range-slider-ui ui-slider" aria-disabled="false"></div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group">
                                <button class="btn button-theme btn-search btn-block" id="searchbtn">
                                    <i class="fa fa-search"></i><strong> <?php echo app('translator')->getFromJson('strings.search'); ?> </strong>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                $('#searchbtn').click(function(){
                    if($('#search').val()==''){
                        $('#search').val('all');
                    }
                    location.href='/search/'+$('#search').val()+'/'+$('#type').val()+'/'+$('[name=min]').val()+'/'+$('[name=max]').val();
                });
            </script>
        <!-- Search area 3 end -->
    </div>
</div>
<!-- Banner end -->


<!-- Featured Properties start -->
<div class="featured-properties content-area-14" style="padding-top:40px;">
    <div class="container <?php echo e(app()->getLocale()=="ar"?"ar":""); ?>">
        <!-- Main title -->
        <div class="main-title">
            <h1><?php echo app('translator')->getFromJson('strings.whats_new'); ?></h1>
            <p><?php echo app('translator')->getFromJson('strings.latest_offers'); ?></p>
        </div>
        <div class="row">
            <?php if(count($newads)>0): ?>
			<?php $__currentLoopData = $newads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">
                <div class="property-box">
                    <div class="property-thumbnail">
                        <div class="property-img">
                            <?php if(Auth::user()&&$n->user==Auth::user()->id): ?>
                            <?php else: ?>
                            <div class="tag <?php echo e(Auth::user()?'':'tagdis'); ?>">
                                <?php
                                    $fa=false;
                                    foreach ($fav as $f) {
                                        if($f->ad==$n->id){
                                            $fa=true;
                                        }
                                    }
                                ?>
                                <?php if(!$fa): ?>
                                <i id="fav<?php echo e($n->id); ?>" class="fa fa-star-o star" title="<?php echo app('translator')->getFromJson('strings.add_to_favourites'); ?>"></i>
                                <?php else: ?>
                                <i id="fav<?php echo e($n->id); ?>" class="fa fa-star star" title="<?php echo app('translator')->getFromJson('strings.remove_from_favourites'); ?>"></i>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="price-box"><span><?php echo e($n->price); ?> <?php echo app('translator')->getFromJson('strings.le'); ?></span> <?php echo e($n->general_type=='rent'?trans('strings.per_month'):''); ?></div>
                            <?php if($n->image==''): ?>
                            <img class="d-block w-100" src="<?php echo e(asset('/img/ads')); ?>/<?php echo e($links[5]->value); ?>" alt="properties" style="height: 330px;object-fit: contain">
                            <?php else: ?>
                            <img class="d-block w-100" src="<?php echo e(asset('/img/ads')); ?>/<?php echo e($n->image); ?>" alt="properties" style="height: 330px;object-fit: contain">
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="detail">
                        <h1 class="title">
                            <a href="/ad/<?php echo e($n->id); ?>" target="_blank"><?php echo e($n->title); ?></a>
                        </h1>
                        <div class="location">
                            <a href="/ad/<?php echo e($n->id); ?>" target="_blank">
                                <i class="flaticon-pin"><?php echo e($n->address); ?></i>
                            </a>
                        </div>
                        <ul class="facilities-list clearfix">
                            <?php if($n->type=="land"): ?>
                            <li>
                                <i class="flaticon-ui"></i><?php echo app('translator')->getFromJson('strings.meter'); ?> <?php echo e($n->size); ?>

                            </li>
                            <?php else: ?>
                            <li>
                                <i class="flaticon-bed"></i><?php echo app('translator')->getFromJson('strings.rooms'); ?>:  <?php echo e($n->rooms); ?>

                            </li>
                            <li>
                                <i class="flaticon-bathroom"></i><?php echo app('translator')->getFromJson('strings.bathrooms'); ?>: <?php echo e($n->pathroom); ?>

                            </li>
                            <li>
                                <i class="flaticon-ui"></i><?php echo app('translator')->getFromJson('strings.meter'); ?> <?php echo e($n->size); ?>

                            </li>
                            <li>
                                <i class="flaticon-car"></i> <?php echo e($n->parking==1?trans('strings.park'):trans('strings.no_park')); ?>

                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                $('#fav<?php echo e($n->id); ?>').click(function(){
                    $.ajax({
                       type:'GET',
                       url:'/fav/<?php echo e($n->id); ?>',
                       success:function(data) {
                            if(data.type==1){
                                $('#fav<?php echo e($n->id); ?>').removeClass("fa-star-o");
                                $('#fav<?php echo e($n->id); ?>').addClass("fa-star");
                                $('#fav<?php echo e($n->id); ?>').prop('title', 'Remove from favourites');
                            }else if(data.type==2){
                                $('#fav<?php echo e($n->id); ?>').removeClass("fa-star");
                                $('#fav<?php echo e($n->id); ?>').addClass("fa-star-o");
                                $('#fav<?php echo e($n->id); ?>').prop('title', 'Add to favourites');
                            }
                            alert(data.msg);
                       }
                    });
                });
            </script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h3><?php echo app('translator')->getFromJson('strings.no_ads'); ?></h3>
            <?php endif; ?>
            <?php if(count($newads)==3): ?>
            <a href="/search" class="btn btn-white btn-read-more"><?php echo app('translator')->getFromJson('strings.show_more'); ?></a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/index.blade.php ENDPATH**/ ?>