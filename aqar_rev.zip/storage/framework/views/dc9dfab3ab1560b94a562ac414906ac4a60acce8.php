<?php $__env->startSection('content'); ?>
<!-- Page Content-->
<h3 class="title"><?php echo app('translator')->getFromJson('strings.login'); ?></h3>
<?php if(count($errors)>0): ?>
    <br>
    <div class="alert alert-danger <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
      <?php $a=[]; $a=session()->pull('m'); ?>
      <div class="alert alert-<?php echo e($a[0]); ?> <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
        <?php echo e($a[1]); ?>

      </div>
    <?php endif; ?>
<form method="POST" action="/login<?php echo e(isset($key)&&$key=='my-Admin925'?'/my-admin':'/user'); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group loginform">
        <div class="row <?php echo e(app()->getLocale()=='ar'?'ar':''); ?>">
            <div class="col-sm-12">
                <label><?php echo app('translator')->getFromJson('strings.email'); ?>:</label>
                <input type="text" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="example@example.com" name="email" value="<?php echo e(old('email')); ?>">
            </div>
            <div class="col-sm-12">
                <label><?php echo app('translator')->getFromJson('strings.password'); ?></label>
                <input type="password" class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
            </div>
            <div class="col-sm-12" style="margin-top:20px;">
                <a href="#"><?php echo app('translator')->getFromJson('strings.reset_password'); ?></a>
            </div>
            <div class="col-sm-12">
                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>><span style="margin-right: 20px"><?php echo app('translator')->getFromJson('strings.remember'); ?></span>
            </div>
            <div class="col-sm-12" style="margin-top:20px;">
                <button class="btn btn-white"><?php echo app('translator')->getFromJson('strings.login'); ?></button>
            </div>
        </div>
    </div>
</form>
<!-- // End Page Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/auth/login.blade.php ENDPATH**/ ?>