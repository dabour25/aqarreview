<?php $__env->startSection('content'); ?>
<div id="content-wrapper">

    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="/admindb">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Links & Data</li>
      </ol>

    <!-- Page Content -->
    <?php if(count($errors)>0): ?>
    <br>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(Session::has('m')): ?>
      <?php $a=[]; $a=session()->pull('m'); ?>
      <div class="alert alert-<?php echo e($a[0]); ?>" style="width: 40%">
        <?php echo e($a[1]); ?>

      </div>
    <?php endif; ?>
    <!-- Page Content -->
        <div class="container">
          <div class="card-body">
            <form action="/admindb/links" method="post">
              <?php echo csrf_field(); ?>
              <label>Phone:</label>
              <input type="text" name="phone" class="form-control" value="<?php echo e($data[0]->value); ?>">
              <label>Email:</label>
              <input type="text" name="email" class="form-control" value="<?php echo e($data[1]->value); ?>">
              <label>FaceBook:</label>
              <input type="text" name="face" class="form-control" value="<?php echo e($data[2]->value); ?>">
              <label>Twiter:</label>
              <input type="text" name="twit" class="form-control" value="<?php echo e($data[3]->value); ?>">
              <label>Instagram:</label>
              <input type="text" name="inst" class="form-control" value="<?php echo e($data[4]->value); ?>">
              <br>
              <button type="submit" class="btn btn-primary">Save</button>
            </form>
            <hr>
            <form action="/admindb/adsdefault" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <label>Default Ads Image</label>
              <br>
              <img src="<?php echo e(asset('/img/ads')); ?>/<?php echo e($data[5]->value); ?>" width="150px">
              <br><br>
              <input type="file" name="default">
              <br><br>
              <button type="submit" class="btn btn-primary">Save</button>
            </div>
          </div>
          </div>
        </div>
  </div>
  <!-- /.content-wrapper -->

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aqar_rev\resources\views/admin/links.blade.php ENDPATH**/ ?>